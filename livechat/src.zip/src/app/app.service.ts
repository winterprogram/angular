import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';

import { Observable, observable } from "rxjs";
import { catchError } from 'rxjs/operators';;
// import { tap } from 'rxjs/operator'
import { map } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class AppService {

  constructor(private http: HttpClient) { }
  baseUrl = "https://chatapi.edwisor.com/api/v1/"

  public signup(data): Observable<any> {
    const params = new HttpParams()
      .set('firstName', data.firstName)
      .set('lastName', data.lastName)
      .set('email', data.email)
      .set('mobileNumber', data.mobileNumber)
      .set('password', data.password)
      .set('apiKey', data.apiKey)

    return this.http.post(this.baseUrl + 'users/signup', params)
  }

}
